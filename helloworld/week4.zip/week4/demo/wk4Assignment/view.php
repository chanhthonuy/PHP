<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>        
    </head>
    <body>
        <?php
        
           include_once './dbconnect.php';
           include_once './dbData.php';
            
          /* $results = getAllTestData(); */
           
           $column = 'corp';
           $searchWord = 'test';
           $db = getDatabase();
           
            $stmt = $db->prepare("SELECT * FROM corps WHERE $column LIKE :search");

            $search = '%'.$searchWord.'%';
            $binds = array(
                ":search" => $search
            );
            $results = array();
            if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            
          //$results = searchTest($column, $search);
            
        ?>
        
        
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                     <th>Company Name</th>
                    <th>Incorporated Date</th>
                    <th>Email</th>
                    <th>Zipcode</th>
                    <th>Owner</th>
                    <th>Phone</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($results as $row): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['corp']; ?></td>
                    <td><?php echo $row['incorp_dt']; ?></td> 
                    <td><?php echo $row['email']; ?></td> 
                    <td><?php echo $row['zipcode']; ?></td> 
                    <td><?php echo $row['owner']; ?></td> 
                    <td><?php echo $row['phone']; ?></td> 
                     </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
           
    </body>
</html>

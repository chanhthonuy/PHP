<form action="#" method="post">
    <fieldset>
        <legend>Form 1</legend>
        
        <label>Data one</label>  
        <input type="radio" name="dataone" value="ford" />
        <input type="radio" name="dataone" value="honda" />

        <label>Data 2</label>  
        <select name="datatwo">
            <option value="eggs">Eggs</option>
            <option value="bread">Bread</option>
        </select>
        <input type="hidden" name="action" value="Submit1" />
        <input type="submit" value="Submit1" />
    </fieldset>    
</form>
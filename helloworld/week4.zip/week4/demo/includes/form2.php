<form action="#" method="post">
    <fieldset>
        <legend>Form 2</legend>
        <label>Data One</label>
        <input name="dataone" type="search" placeholder="Search...." />
        <input name="datatwo" value="data2" type="hidden" />
    
         <input type="hidden" name="action" value="Submit2" />
        <input type="submit" value="Submit" />
    </fieldset>            
</form>
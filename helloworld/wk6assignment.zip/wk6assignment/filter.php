

<form name="filter" action="#" method="get">
    <label>Filter By:</label>
     <select name='columns'><option value='schoolName'>School Name</option><option value='city'>City</option><option value='state'>State</option></select>    
     <input type="text" name="search" value="">
   <input type="hidden" name="action" value="filter">
    <input type="submit" name="submit" value="Filter"  class="btn btn-success">

</form>    
        
 
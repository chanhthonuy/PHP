<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        include './dbconnect.php';
        include './functions.php';

        $results = '';

        if (isPostRequest()) {
            $db = getDatabase();

            $stmt = $db->prepare("INSERT INTO actors SET id = :id, firstname = :firstname, lastname = :lastname, height= :height");

            $id = filter_input(INPUT_POST, 'id');
            $firstname = filter_input(INPUT_POST, 'firstname');
            $lastname = filter_input(INPUT_POST, 'lastname');          
            $height = filter_input(INPUT_POST, 'height');

            $binds = array(
                ":id" => $id,
                ":firstname" => $firstname,
                ":lastname" => $lastname,               
                ":height" => $height
            );


            /*
             * empty()
             * isset()
             */

            if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                $results = 'Data Added';
            }
        }
        ?>

        <h1>Add Actor Data</h1>
        <form method="post" action="viewActor.php">
            <button type="submit">View Actor Table</button>
            <br />
        </form>
        <h2><?php echo $results; ?></h2>

        <form method="post" action="addActor.php">            
            ID <input type="number" value="" name="id" />
            <br />
            First Name <input type="text" value="" name="firstname" />
            <br />
            Last Name <input type="text" value="" name="lastname" />
            <br />          
            Height <input type="text" value="" name="height" />
            <br />

            <input type="submit" value="Submit" />
        </form>
    </body>
</html>

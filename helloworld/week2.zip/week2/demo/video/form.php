<form>
    <input type="text" />
</form>

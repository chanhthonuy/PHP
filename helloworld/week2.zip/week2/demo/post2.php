<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       <form method="post" action="post-process.php">
            
            Data one <input type="text" value="" name="dataone" />
            <br />
            Data two <input type="text" value="" name="datatwo" />
            <br />
            
            <input type="submit" value="Submit" />
            
        </form>
        
    </body>
</html>

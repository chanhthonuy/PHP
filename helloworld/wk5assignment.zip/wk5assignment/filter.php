

<form name="filter" action="#" method="get">
    <label>Filter By:</label>
     <select name='columns'><option value='labUsageid'>Lab Usage ID</option><option value='studentId'>Student ID</option><option value='roomNumber'>Room Number</option><option value='dayTimeSignIn'>Time Sign In</option><option value='dayTimeSignOut'>Time Sign Out</option></select>    
     <input type="text" name="search" value="">
   <input type="hidden" name="action" value="filter">
    <input type="submit" name="submit" value="Filter"  class="btn btn-success">

</form>    
        
 
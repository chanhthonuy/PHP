

<form name="filter" action="#" method="get">
    <label>Filter By:</label>
     <select name='columns'><option value='id'>ID</option><option value='corp'>Company Name</option><option value='incorp_dt'>Date</option><option value='email'>Email</option><option value='zipcode'>Zipcode</option><option value='owner'>Owner</option><option value='phone'>Phone</option></select>    
     <input type="text" name="search" value="">
   <input type="hidden" name="action" value="filter">
    <input type="submit" name="submit" value="Filter"  class="btn btn-success">

</form>    
        
 
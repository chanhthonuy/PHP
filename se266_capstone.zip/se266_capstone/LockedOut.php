<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BarberStop</title>
        <link rel="stylesheet" type="text/css" href="assets/landingStyles.css">
              
    </head>
    <body>
        
        <?php
        
        
        
        ?>
        
        <section class="intro">
            
            <div class="inner">
                <div class="content">
                    <h1>Your Account Has Been Locked </h1>
               </div>
            </div>
            
            
            
        </section>    
      
      
        
        
        
        
    </body>
</html>

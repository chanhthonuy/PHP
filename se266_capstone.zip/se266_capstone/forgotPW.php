<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Website CSS style -->
        <link rel="stylesheet" type="text/css" href="assets/stylesUserReg.css">



        <!-- Google Fonts -->
        <link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>

        <title>User Registry</title>
    <div style="border: 5px solid black; background-color: #d3d3d3;">
        <h1 class="title">Barber<span class="BSTOP" style="color: red; font-weight: bolder;">Stop</span></h1>
        <h1 style="color: black; float: right;">User<span class="BSTOP" style="font-weight: bolder; color: red">Forgot Password</span></h1>
    </div>

</head>
<style>
    .div-form{
        width:350px; 
        background-color:rgba(0, 0, 0, 0.8);
        border-radius:20px; 
        border:1px solid red;
        padding:20px;
    }
    .label{
        color:whitesmoke
    }
    .title-red{
        color:red;
        font-size:1.5em;
    }
</style>
<body>

    <?php
    include './functions/dbconnect.php';
    include './functions/postrequest.php';
    include './functions/salt.php';
    // START THE SESSION:
    session_start();
    $message = $name_found = $uname = $sq_form = "";
    $results = array();
    $_SESSION['LoggedIn'] = false;
    $db = getDatabase();

    if (isset($_POST["submit"])) {
        $uname = $_POST["uname"];
        $stmt = $db->prepare("SELECT security_question FROM usersignup WHERE userName = '$uname';");

        if ($stmt->execute() && $stmt->rowCount() > 0) {
            $message = "One User Found";
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($results as $data) {
                
                $sq_form = "<form method='post'>"
                ."<label class='label'>" . $data['security_question'] . "</label>"
                ."<input type='text' name='sq_answer_text' />"  
                ."<input type='submit' name='answer_submit' />"      
                . "</form>";
            }
        } else {
            $message = "No Users Have Been Found With The Name '$uname'";
        }
    }
    ?>
<center>
    <div class="div-form">

        <div class="row main">
            <form method="post" id="name-form">
                <label class="title-red">Enter Your Information</label>
                <br/>
                <label class="label">Enter Your Username</label>
                <input type="text" name="uname" required/>
                <br/>
                <input type="submit" name="submit" onclick="this.visible=false"/>
                <br/>
            </form>
            <br/>
            <label class="label"><?php echo $message; ?></label>
            <br/>
            <br/>
            <br/>

        </div>
</center>
</div>

<script type="text/javascript">

</script>


<script type="text/javascript" src="assets/js/bootstrap.js"></script>
</body>

</html>

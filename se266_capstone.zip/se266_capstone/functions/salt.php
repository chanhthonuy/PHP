<?php

function Salt() {
   return "#!8dlkj90";  
}



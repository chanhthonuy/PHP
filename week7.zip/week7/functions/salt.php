<?php
function salt() {
	return "@b3!z#";
}

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="assets/barberLogin.css">
        <title>User Login</title>
    </head>
    <body>
        <?php
        session_start();

        $_SESSION['LoggedIn'] = false;

        include './functions/dbconnect.php';
        include './functions/postrequest.php';
        include './functions/salt.php';

        $getDB = getDatabase();
        
        $username = '';
        $password = '';
        $salt = salt();
        $limit = 10;    // Number of tries to login on a user. ##

        if (isPostRequest()) {
            $username = filter_input(INPUT_POST, 'username');
            $password = filter_input(INPUT_POST, 'password');
            $salt = Salt();

            $encryptedPwd = sha1($password) . $salt;
            
             if ($_SESSION['username'] != $username) {
                $_SESSION['attempts'] = 1;
                $_SESSION['username'] = $username;
            } else {
                if ($username != "administrator") {
                    $_SESSION['attempts'] ++;
                }
            }

            $sql = $getDB->prepare("SELECT * FROM userSignUp WHERE userName = '$username' AND password = '$encryptedPwd';");
    
             // Grab data from the database. ##
            $result = array();
            if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($result['locked']) {
                    header('Location: locked-out.php');
                } else {
                    if ($pwd === $result['pwd']) {
                        $_SESSION['loggedin'] = "TRUE";                    
                        $_SESSION['home'] = "true";

                        $stmt = $db->prepare("UPDATE usersignup SET last_login = now() WHERE username = :username");

                        $binds = array(
                            ":username" => $username
                        );

                        if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                            if ($username == "administrator") {
                                header('Location: admin.php');
                            } else {
                                header('Location: UserHomePage.php');
                            }
                        } else {
                            header('Location: error.php');
                        }
                    } else {
                        $err = incorrect();

                        if ($_SESSION['attempts'] >= $limit) {
                            $stmt = $db->prepare("UPDATE user_accounts SET locked = true WHERE uname = :uname");

                            $binds = array(
                                ":uname" => $uname
                            );

                            if ($stmt->execute($binds) && $stmt->rowCount() > 0) {
                                $_SESSION['attempts'] = 1;
                                header('Location: locked-out.php');
                            }
                        }
                    }
                }
            } else {
                $err = incorrect();
            }
        }

        function incorrect() {
            $_SESSION['loggedin'] = "FALSE";
            $_SESSION['username'] = "";
            $_SESSION['password'] = "";
        
            return "Incorrect Username and/or Password!";
        }
        ?>
        <div class="login" style="width:250px; background-color:rgba(0, 0, 0, 0.8); border-radius:20px; border:1px solid red;">
            <form action="#" method="POST">
                <h1>Barber<span style="color: red; border: solid black 3px; border-radius: 9px;">Stop</span></h1>
                 
                <input type="text" name="username" id="username" placeholder="username" required><br><br>
                <input type="password" name="password" id="password" placeholder="password" required><br><br>
                <input type="submit" name="submit" id="submit">
                <br/>
                <br/>
                <label style="color:whitesmoke; font-size:14px;">Not A Member? Click<a href="userRegistry.php" id="login_link"> Here </a>To Sign Up</label>
                <br/>
                <a href="forgotPW.php" style="color:whitesmoke; font-size:14px;">Forgot Password?</a>
                 <br/>
                    <br/>
                <a href="landingPage.php" style="float:right; color:whitesmoke;"> ◄ Main Menu</a>
            </form>
    </body>
    <style>
        #login_link{
            font-weight: bold;
            color:red;
            text-decoration: none;
            font-size:14px;
        }
        #login_link:hover{
            
            color:orange;
        }
    </style>
</html>

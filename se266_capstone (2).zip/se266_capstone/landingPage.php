<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BarberStop</title>
        <link rel="stylesheet" type="text/css" href="assets/landingStyles.css">

    </head>
    <body>

        <?php
        ?>

        <section class="intro">

            <div class="inner">
                <div class="content">

                    <h1 style="background-color: whitesmoke; border: solid black 3px; border-radius: 9px">Barber<span style="color: red;">Stop</span></h1>
                    <div class="btndiv">
                        <br><br><br>
                        <form method="" action=""> 
                         
                            <a class="btn" href="barberLogin.php" style="color: red; background-color: whitesmoke;"/>Login as Barber</a>
                            <br>
                            <br>
                            <br>
                            <a class="btn" href="UserLogin.php" style="color:red; background-color: whitesmoke;">Login As User</a>
                            <br>
                            <br>
                            <br>
                            <a class="btn" href="barberRegistry.php" style="color:red; background-color: whitesmoke;">Barber Registry</a>
                            <br>
                            <br>
                            <br>
                            <a class="btn" href="userRegistry.php" style="color:red; background-color: whitesmoke;">User Registry</a> 

                        </form>
                        <br><br><br>
                    </div>    
                </div>
            </div>



        </section>    






    </body>
</html>

<form action="?" method="post">
    <p>
        <input type="submit" name="action" value="Empty cart">
    </p>
</form>
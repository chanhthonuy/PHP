<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        
        session_start();
        
        $page1 = 'page1 var';
        $_SESSION['page1'] = 'page1 session';
        
        ?>
    </body>
</html>

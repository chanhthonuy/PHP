
<form name="sort" action="#" method="get">
    <label>Sort By:</label>
    <select name='columns'><option value='schoolName'>School Name</option><option value='city'>City</option><option value='state'>State</option></select>    
    <input type="radio" name="sortBy" value="asc" >Ascending
    <input type="radio" name="sortBy" value="desc">Descending
    <input type="hidden" name="action" value="sort">
    <input type="submit" name="submit" value="Sort" class="btn btn-success">
   
        
    <br />
</form>

